# -WhatsApp-Chatbot-Using-OpenAI
 WhatsApp Chatbot Using OpenAI  * Developed a WhatsApp Chatbot utilizing OpenAI's GPT-3 model to provide automated customer  support and engagement.  * Integrated the chatbot with the WhatsApp Business API for seamless communication with users
